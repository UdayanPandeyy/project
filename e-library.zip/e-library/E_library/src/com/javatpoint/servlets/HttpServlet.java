package com.javatpoint.servlets;

public class HttpServlet {

}
