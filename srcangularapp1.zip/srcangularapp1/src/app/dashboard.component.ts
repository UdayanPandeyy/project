import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'dashboard',
    template:  `
        <h1>Welcome back, {{ name }}</h1>
    `
})
export class DashboardComponent  implements OnInit {

    name: string;

    ngOnInit() {
        this.name = sessionStorage['name'];
    }

}