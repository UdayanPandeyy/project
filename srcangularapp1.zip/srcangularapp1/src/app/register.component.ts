import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'register',
    template: `
        <form (ngSubmit)="register()">
            Enter name : <input [(ngModel)]=user.name name="name" /> <br/>
            Enter email : <input [(ngModel)]=user.email name="email" /> <br/>
            Enter password : <input [(ngModel)]=user.password name="password" /> <br/>
            Enter city : <input [(ngModel)]=user.city name="city" /> <br/>
            <button type="submit">Register</button>
        </form>
        <h1>{{statusMessage}}</h1>
    `
})
export class RegisterComponent {

    user: User = new User();
    statusMessage: string;

    constructor(private http: HttpClient) {

    }

    register() {
        var url = "http://localhost:8080/register";
        this.http.post(url, this.user).subscribe(data => {
            alert(JSON.stringify(data));
            //if(data.statusCode == 123)
            this.statusMessage = data.statusMessage;

            //code to handle the response from the server
        })
        //alert(JSON.stringify(this.user));
    }
}

class User {
    name: string;
    email: string;
    password: string;
    city: string;
}