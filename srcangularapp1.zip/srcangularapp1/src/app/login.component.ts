import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
    selector: 'login', 
    template : `
        <form (ngSubmit)="loginCheck()">
            Email ID : <input [(ngModel)]=login.email name="email" /> <br />
            Password : <input [(ngModel)]=login.password name="password"  /> <br />
            <button type="submit">Login</button>
        </form>
    `
})
export class LoginComponent {

    login: Login = new Login();

    constructor(private http: HttpClient, private router: Router) {

    }

    loginCheck() {
        var url = "http://localhost:8080/login";
        this.http.post(url, this.login).subscribe(data => {
            alert(JSON.stringify(data));
            if(data.statusCode==333)
            {
                sessionStorage['name']=data.loggedInCustomer.name;
                this.router.navigate(['/dashboard']);
            }
            else if(data.statusCode == 222) {
                
            }
        })
    }

}

class Login {
    email: string;
    password: string;
}
