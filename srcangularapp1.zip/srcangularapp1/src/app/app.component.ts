import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <!--The content below is only a placeholder and can be replaced.-->
    <div class="header">
      <a routerLink="login">Login</a> | 
      <a routerLink="register">Register</a>
    </div>
    <div style="text-align:center" class="content">
      <router-outlet></router-outlet>
    </div>
    <div class="footer">

    </div>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'angular-app';
}
