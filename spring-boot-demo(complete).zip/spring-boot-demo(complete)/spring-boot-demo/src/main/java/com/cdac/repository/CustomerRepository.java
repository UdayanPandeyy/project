package com.cdac.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.entity.Customer;
import com.cdac.entity.Order;

@Repository
public class CustomerRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void save(Customer customer) {
		entityManager.merge(customer);
	}
	
	public Customer fetch(int customerId) {
		return entityManager.find(Customer.class, customerId);
	}
	
	public Customer fetch(String email) {
		return (Customer)
				entityManager
				.createQuery("select c from Customer c where c.email = :em")
				.setParameter("em", email)
				.getSingleResult();
	}
	
	public List<Customer> fetchByCity(String city) {
		return entityManager
				.createQuery("select c from Customer c where c.city = :ct")
				.setParameter("ct", city)
				.getResultList();
	}
	
	public List<Order> fetchOrders(double amount) {
		return entityManager
				.createQuery("select o from Order o join fetch o.customer c where o.amount >= :amt")
				.setParameter("amt", amount)
				.getResultList();
	}
	
	public long isValidUser(String email, String password) {
		return (Long) 
				entityManager
				.createQuery("select count(c) from Customer c where c.email = :em and c.password = :pwd")
				.setParameter("em", email)
				.setParameter("pwd", password)
				.getSingleResult();
	}
	
}
